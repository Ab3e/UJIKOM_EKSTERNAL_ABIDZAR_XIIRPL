import React from 'react';
import './App.css';
import ProjectsPage from './components/ProjectsPage';
import ProjectPage from './components/ProjectPage';
import HomePage from './home/HomePage';
import AboutPage from './about/AboutPage';
import Contact from './contact/Contact';
import Login from './login/Login';
import Logout from './logout/Logout';
import InfoIcon from '@mui/icons-material/Info';
import HomeIcon from '@mui/icons-material/Home';
import RestaurantMenuIcon from '@mui/icons-material/RestaurantMenu';
import ContactsIcon from '@mui/icons-material/Contacts';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import Create from './create/Create';
import { BrowserRouter, Route, Routes, NavLink } from 'react-router-dom';

function App() {
  const localUsername = localStorage.getItem("username")

  return (
    <BrowserRouter>
      {localUsername ?
        <>
          <header className="sticky">
            <div className='oyo'>
              <span className="logo">
                <img src="/img/kitchen kicik PP.png" alt="logo" width={'160'} />
              </span>
            </div>
            <div className='oya'>
              <NavLink to="/about">
                <button className='ButtonAppAbout1'><InfoIcon /> ABOUT</button>
              </NavLink>
              <NavLink to="/">
                <button className='ButtonAppHome1'><HomeIcon /> HOME</button>
              </NavLink>
              <NavLink to="/projects">
                <button className='ButtonAppMenu1'><RestaurantMenuIcon /> MENU</button>
              </NavLink>
              <NavLink to="/contact">
                <button className='ButtonAppContact1'><ContactsIcon /> CONTACT</button>
              </NavLink>
              <NavLink to="/logout">
                <button className='ButtonAppLogout1'><AccountCircleIcon /> LOGOUT</button>
              </NavLink>
            </div>
          </header>
        </> :
        <>
          <header className="sticky">
            <div className='oyo'>
              <span className="logo">
                <img src="/img/kitchen kicik PP.png" alt="logo" width={'160'} />
              </span>
            </div>
            <div className='oya'>
              <NavLink to="/about">
                <button className='ButtonAppAbout1' onClick={() => alert("you must login")}><InfoIcon /> ABOUT</button>
              </NavLink>
              <NavLink to="/home">
                <button className='ButtonAppHome1' onClick={() => alert("you must login")}><HomeIcon /> HOME</button>
              </NavLink>
              <NavLink to="/projects">
                <button className='ButtonAppMenu1' onClick={() => alert("you must login")}><RestaurantMenuIcon /> MENU</button>
              </NavLink>
              <NavLink to="/contact">
                <button className='ButtonAppContact1' onClick={() => alert("you must login")}><ContactsIcon /> CONTACT</button>
              </NavLink>
              <NavLink to="/login">
                <button className='ButtonAppLogin1'><AccountCircleIcon /> LOGIN</button>
              </NavLink>
            </div>
          </header>
        </>}


      <div className="container">
        <Routes>
          {localUsername ?
            <>
              <Route path="/" index element={<HomePage />} />
              <Route path="/projects" element={<ProjectsPage />} />
              <Route path='/projects/:id' element={<ProjectPage />} />
              <Route path='/about' element={<AboutPage />} />
              <Route path='/contact' element={<Contact />} />
              <Route path='/create' element={<Create />} />
              <Route path='/login' element={<Login />} />
              <Route path='/logout' element={<Logout />} />
            </> :
            <>
              <Route path='/login' element={<Login />} />
              <Route index element={<Login />} />
            </>}
        </Routes>
      </div>
    </BrowserRouter>

  );
}

export default App;
