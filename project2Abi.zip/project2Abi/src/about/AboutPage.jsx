import React from "react";
import './About.css';
import { Link } from "react-router-dom";
import InstagramIcon from '@mui/icons-material/Instagram';
import WhatsAppIcon from '@mui/icons-material/WhatsApp';
import EmailIcon from '@mui/icons-material/Email';
import { handleBreakpoints } from "@mui/system";
const AboutPage = () => {
    return (
        <div>
            <img className="IMG2" src="./imghomepage/IMG2.jpg" alt="" />
            <h1 className="aboutsatu">Semangat Baru Kitchen Kicik</h1>
            <h2 className="aboutdua">Hai, Perkenalkan logo baru kami : Hero</h2>
            <h3 className="abouttiga">Hero datang dari mimpi Kitchen Kicik yang ingin membantu memudahkan kehidupan orang banyak melalui teknologi.</h3>
            <h3 className="abouttiga1">Berawal dari layanan transportasi, sekarang website Kitchen Kicik akan membantu pelayanan kalian yang menjadi solusi buat tantangan sehari. Berkat itu juga, kitchen Kicik menjadi salah satu website teknologi terbaru yang akan melayani jutaan pengguna di Indonesia dengan mengembangkan website kami untuk customer. </h3>
            <h3 className="abouttiga2">Hiro menjadi simbol yang akan mengingatkan kita semua kalau Kitchen Kicik punya berbagai solusi, untuk setiap situasi. Memberikan kamu power untuk melewati hari-harimu. pengingat bahwa dibalik setiap tantangan, pasti ada solusi untuk melewatinya, Karna dengan kitchen Kicik</h3>
            <h1 className="aboutsatu">#KenyangAdaJalan</h1>
            <div className="DescPPKAJ">
            <img src="/img/kitchen kicik PP.png" alt="" width={350} /> 
            </div>
            <h3 className="DescPP">Kitchen Kicik memulai perjalanannya pada tahun 2024 dengan tujuann pertama kami yaitu pemenuhan kebutuhan transaksi makanan melalui website.</h3>
            <div className="aboutlima">
            <h5> KETUK KAMI UNTUK INFO MENARIK LAINNYA : </h5>
            <div className="IconAbout">
                <Link to='https://www.instagram.com/' className="IconAbout"> <InstagramIcon/></Link>
                <Link to='https://www.whatsapp.com/' className="IconAbout"> <WhatsAppIcon/></Link>
                <Link to='https://mail.google.com/' className="IconAbout"> <EmailIcon/></Link>
            </div>         
            <Link to='/'>
                <button> HOME </button>
            </Link>
            <Link to='/projects'>
                <button> MENU </button>
            </Link>
            <Link to='/contact'>
                <button> CONTACT </button>
            </Link>
            </div>
        
        </div>
    )
}

export default AboutPage

// KAMI ADALAH PERUSAHAAN YANG BERDIRI PADA BIDANG KULINER DENGAN RASA DAN KUALITAS TERBAIK DENGAN HARGA YANG TERJANGKAU UNTUK SEMUA KALANGAN

// Berawal dari layanan transportasi, sekarang website Kitchen Kicik akan membantu pelayanan kalian yang menjadi solusi buat tantangan sehari. Berkat itu juga, kitchen Kicik menjadi salah satu website teknologi terbaru yang akan melayani jutaan pengguna di Indonesia dengan mengembangkan website kami untuk customer.

// Hiro menjadi simbol yang akan mengingatkan kita semua kalau Kitchen Kicik punya berbagai solusi, untuk setiap situasi. Memberikan kamu power untuk melewati hari-harimu. pengingat bahwa dibalik setiap tantangan, pasti ada solusi untuk melewatinya, Karna dengan kitchen Kicik #KenyangMudahTujuan