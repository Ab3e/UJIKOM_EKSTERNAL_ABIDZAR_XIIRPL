import axios from "axios";

const url = "http://localhost:4000/user";

const loginHandler = {
    async get() {
        return axios
            .get(url)
            .then((result) => result.data)
            .catch((e) => e.message);
    },
}

export default loginHandler