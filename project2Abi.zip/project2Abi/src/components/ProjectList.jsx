import React, { useState } from 'react'
import ProjectCard from './ProjectCard'
import ProjectForm from './ProjectForm'
import { projectAPI } from './projectAPI'
import { Link } from 'react-router-dom'
import '../App.css'

const ProjectList = ({ projects, onSave }) => {
    const [projectBeingEdited, setProjectBeingEdited, projectBeingDeleted, setProjectBeingDeleted] = useState({})
    const [search, setSearch] = useState("")
    const [data, setData] = useState([])

    const handleEdit = (project) => {
        setProjectBeingEdited(project)
    }

    const cancelEditing = () => {
        setProjectBeingEdited({})
    }

    const handleDelete = async (id) => {
        setData(data.filter((data) => data.id !== id))
        await projectAPI.delete(id)
        window.location = "/projects"
    }

    return (
        <>
            <div className='create'>
                <input type="text" className="search" placeholder="Search.." onChange={(e) => setSearch(e.target.value)} />
                <Link to="/create">
                    <button>CREATE</button>
                </Link>
            </div>
            <div className="row">
                {projects
                    .filter(item => item.name.toLowerCase().indexOf(search) > -1)
                    .map((project) => (
                        <div key={project.id} className='cols-sm'>
                            {project === projectBeingEdited ? (
                                < ProjectForm onSave={onSave} onCancel={cancelEditing} project={project} />
                            ) : (
                                <ProjectCard project={project} onEdit={handleEdit} onDelete={handleDelete} />
                            )}
                        </div>
                    ))}
            </div>
        </>
    )
}

export default ProjectList
