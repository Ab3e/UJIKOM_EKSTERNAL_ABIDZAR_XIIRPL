import React from "react";
import "./Contact.css";
import ContactsIcon from '@mui/icons-material/Contacts';

function Contact() {


    return (

        <div className="leftside">
            <h1> <ContactsIcon /> COMPLAIN/ORDER</h1>
            <div className="form">
                <form id="contact-form" method="POST">
                    <label htmlFor="nama" className="ContactLabel">Nama Anda</label>
                    <input name="name" placeholder="Masukkan Nama Lengkap Anda..." type="text" />
                    <label htmlFor="email" className="ContactLabel">Email Anda</label>
                    <input email="email" placeholder="Masukkan Email Anda..." type="email" />
                    <label htmlFor="message" className="ContactLabel">Pesan Anda</label>
                    <textarea
                        rows="3"
                        placeholder="Masukkan Pesan Anda"
                        name="message"
                        required
                    ></textarea>
                    <button type="submit" className="ContactLabel" onClick={() => alert("Thank you", window.location.reload())}>Kirim Pesan</button>
                </form>
            </div>
        </div >
    )
}

export default Contact

// class PopUp extends Component {
//     constructor(props) {
//        super(props);
//        this.state = {
//            hide: false
//        };
//     }
//     clicked(){
//         this.setState({
//           hide: true
//         });
//     }
//     render() {
//         return (
//            <div>
//            <button type="button" class="btn btn-primary" data-toggle="modal" onClick={() => this.clicked()} >
//                Click Me
//            </button>
//            {
//              this.state.hide?
//                  <div class="modal fade" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">Required PopUp </div>
//                  : null
//            }
//            </div>
//         );
//      }
//    }

// export default Contact